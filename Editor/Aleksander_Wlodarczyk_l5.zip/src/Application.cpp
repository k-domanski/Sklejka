#include "Test.h"

auto main() -> int {
  Engine::TestWindow();
  return 0;
}
